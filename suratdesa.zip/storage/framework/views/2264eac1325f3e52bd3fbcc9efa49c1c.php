<?php $__env->startSection('title', 'Admin - Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Dashboard</h1>
        </div>

        <div class="row">
            <p><b>Total Seluruh Surat : <?php echo e($total_surat); ?></b></p>

            <div class="col-4">
                <div class="card text-white bg-primary mb-3">
                    <div class="card-header">Surat Belum Menikah</div>
                    <div class="card-body">
                        <h5 class="card-title">Total Jumlah Surat : <?php echo e($total_belum_menikah); ?></h5>
                        <p class="card-text">
                            Belum Dikonfirmasi : <?php echo e($konfirmasi_belum_menikah); ?><br>
                            Ditolak : <?php echo e($ditolak_belum_menikah); ?><br>
                            Diproses : <?php echo e($proses_belum_menikah); ?><br>
                            Selesai : <?php echo e($selesai_belum_menikah); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card text-white bg-success mb-3">
                    <div class="card-header">Surat KTP Sementara/Domisili</div>
                    <div class="card-body">
                        <h5 class="card-title">Total Jumlah Surat : <?php echo e($total_ktp_domisili); ?></h5>
                        <p class="card-text">
                            Belum Dikonfirmasi : <?php echo e($konfirmasi_ktp_domisili); ?><br>
                            Ditolak : <?php echo e($ditolak_ktp_domisili); ?><br>
                            Diproses : <?php echo e($proses_ktp_domisili); ?><br>
                            Selesai : <?php echo e($selesai_ktp_domisili); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card text-white bg-dark mb-3">
                    <div class="card-header">Surat Kematian</div>
                    <div class="card-body">
                        <h5 class="card-title">Total Jumlah Surat : <?php echo e($total_kematian); ?></h5>
                        <p class="card-text">
                            Belum Dikonfirmasi : <?php echo e($konfirmasi_kematian); ?><br>
                            Ditolak : <?php echo e($ditolak_kematian); ?><br>
                            Diproses : <?php echo e($proses_kematian); ?><br>
                            Selesai : <?php echo e($selesai_kematian); ?>

                        </p>
                    </div>
                </div>
            </div>

        </div>

        <hr>

        <div class="row mb-5">
            <div class="col-3"></div>

            <div class="col-6">
                <canvas id="dashboardChart"></canvas>
            </div>

            <div class="col-3"></div>
        </div>

        <br>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        const ctx = document.getElementById('dashboardChart');

        const data = {
            labels: [
                'Belum Menikah',
                'KTP Sementara/Domisili',
                'Kematian'
            ],
            datasets: [{
                label: 'Total Surat : ',
                data: [<?php echo e($total_belum_menikah); ?>, <?php echo e($total_ktp_domisili); ?>, <?php echo e($total_kematian); ?>],
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 205, 86)'
                ],
                hoverOffset: 4
            }]
        };

        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                onClick: (e) => {
                    const canvasPosition = getRelativePosition(e, chart);

                    // Substitute the appropriate scale IDs
                    const dataX = chart.scales.x.getValueForPixel(canvasPosition.x);
                    const dataY = chart.scales.y.getValueForPixel(canvasPosition.y);
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suratdesa\resources\views/back/dashboard/index.blade.php ENDPATH**/ ?>