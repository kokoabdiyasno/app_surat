<!DOCTYPE html>
<html>

<head>
    <title>Sistem Pengajuan Surat</title>
</head>

<body>
    <p>Hallo <?php echo e($data['nama']); ?>, pengajuan surat anda melalui sistem dengan detail sebagai berikut :</p>

    
    <?php if($data['status'] == 1): ?>
        <p>Kami nyatakan <b>DITOLAK</b> dikarenakan, <?php echo e($data['alasan_ditolak']); ?></p>
    <?php elseif($data['status'] == 2): ?>
        
        <p>Kami nyatakan <b>DITERIMA</b>, Silahkan menunggu selagi admin memproses pengajuan anda</p>
    <?php else: ?>
        <p>Kami nyatakan <b>SELESAI</b>, Dibawah ini adalah file pengajuan surat anda</p>
    <?php endif; ?>

    <p>Jenis Surat : <?php if($data['tipe'] == 1): ?>
            Belum Menikah
        <?php elseif($data['tipe'] == 2): ?>
            KTP Sementara/Domisili
        <?php else: ?>
            Kematian
        <?php endif; ?>
    </p>
    <p>Nama : <?php echo e($data['nama']); ?></p>
    <p>Jenis Kelamin : <?php echo e($data['jenis_kelamin']); ?></p>
    <p>Tanggal Lahir : <?php echo e(date('d/m/Y', strtotime($data['tanggal_lahir']))); ?></p>
    <p>Email : <?php echo e($data['email']); ?></p>
    <p>No Telepon : <?php echo e($data['no_telepon']); ?></p>
    <p>Alamat/Tempat Tinggal : <?php echo e($data['alamat']); ?></p>
    <p>Catatan : <?php echo e($data['catatan']); ?></p>

    <?php if($data['hasil_surat'] != null): ?>
        <?php echo e($message->embed(asset('/back/pdf/'. $data['hasil_surat']))); ?>

    <?php endif; ?>

</body>

</html>
<?php /**PATH C:\laragon\www\suratdesa\resources\views/mail/konfirmasi-pengajuan-email.blade.php ENDPATH**/ ?>