<?php $__env->startSection('title', 'Admin - Profil'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Data Profil</h1>
        </div>

        <?php if($errors->any()): ?>
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="dataTable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Judul</th>
                        <th>Isi</th>
                        <th>Status</th>
                        <th>Gambar</th>
                        <th>Fungsi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $profils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->judul); ?></td>
                            <td><?php echo e(Str::limit(strip_tags($item->isi), 120, '...')); ?></td>
                            <td><?php echo e($item->status); ?></td>
                            <td class="text-center" width="20%">
                                <img src="<?php echo e(asset('back/img/' . $item->gambar)); ?>" alt="gambar" width="100%">
                            </td>
                            <td class="text-center" width="10%">
                                <button class="btn btn-secondary mb-1" data-bs-toggle="modal"
                                    data-bs-target="#modalDetail<?php echo e($item->id); ?>">Detail</button>
                                <button class="btn btn-success mb-1" data-bs-toggle="modal"
                                    data-bs-target="#ubahModal<?php echo e($item->id); ?>">Ubah</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Modal -->
    <?php $__currentLoopData = $profils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="ubahModal<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title" id="staticBackdropLabel">Ubah Profil (<?php echo e($item->status); ?>)</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(url('admin-profil/' . $item->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="gambarLama" value="<?php echo e($item->gambar); ?>">
                            <input type="hidden" name="status" value="<?php echo e($item->status); ?>">

                            <div class="mb-3">
                                <label for="judul">Judul</label>
                                <input type="text" name="judul" id="judul" class="form-control"
                                    value="<?php echo e(old('judul', $item->judul)); ?>">
                            </div>

                            <div class="mb-3">
                                <label for="myeditor">Isi</label>
                                <textarea name="isi" id="myeditor<?php echo e($item->id); ?>" class="form-control" class="form-control">
                                    <?php echo e(old('isi', $item->isi)); ?>

                                </textarea>
                            </div>

                            <div class="mb-3">
                                <label for="gambar">Gambar <small>(Max 3 MB)</small></label>
                                <input type="file" name="gambar" id="gambar<?php echo e($item->id); ?>" class="form-control">

                                <div class="mt-1">
                                    <img id="img-view<?php echo e($item->id); ?>" src="<?php echo e(asset('back/img/' . $item->gambar)); ?>"
                                        class="img-thumbnail img-preview" width="100px" alt="">
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                    </div>
                    </form>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Modal Detail -->
    <?php $__currentLoopData = $profils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="modalDetail<?php echo e($item->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
            tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-secondary text-white">
                        <h5 class="modal-title" id="staticBackdropLabel">Detail Profil (<?php echo e($item->status); ?>)</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <table class="table table-bordered table-striped">
                            <tr>
                                <td>Judul</td>
                                <td><?php echo e($item->judul); ?></td>
                            </tr>

                            <tr>
                                <td>Isi</td>
                                <td><?php echo $item->isi; ?></td>
                            </tr>

                            <tr>
                                <td>Gambar</td>
                                <td class="text-center">
                                    <img src="<?php echo e(asset('back/img/' . $item->gambar)); ?>" alt="gambar" width="100%">
                                </td>
                            </tr>
                        </table>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.20.1/basic/ckeditor.js"></script>

    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>

    <?php $__currentLoopData = $profils; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            CKEDITOR.replace('myeditor<?php echo e($item->id); ?>');
        </script>

        <script>
            $("#gambar<?php echo e($item->id); ?>").change(function() {
                readURL<?php echo e($item->id); ?>(this);
            });

            function readURL<?php echo e($item->id); ?>(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#img-view<?php echo e($item->id); ?>').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('back.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suratdesa\resources\views/back/profil/index.blade.php ENDPATH**/ ?>