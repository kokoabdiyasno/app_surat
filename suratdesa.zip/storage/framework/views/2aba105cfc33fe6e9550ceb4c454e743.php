<?php $__env->startSection('title', 'Admin - Detail Surat'); ?>

<?php $__env->startSection('content'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-surats-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Detail Pengajuan Surat</h1>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <tr>
                    <th>Jenis Surat</th>
                    <td>
                        <?php if($surat->tipe == 1): ?>
                            Surat Belum Menikah
                        <?php elseif($surat->tipe == 2): ?>
                            Surat KTP Sementara/Domisili
                        <?php else: ?>
                            Surat Kematian
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>Nama</th>
                    <td><?php echo e($surat->nama); ?></td>
                </tr>

                <tr>
                    <th>Jenis Kelamin</th>
                    <td><?php echo e($surat->jenis_kelamin); ?></td>
                </tr>

                <tr>
                    <th>Tanggal Lahir</th>
                    <td><?php echo e(date('d/m/Y', strtotime($surat->tanggal_lahir))); ?></td>
                </tr>

                <tr>
                    <th>Alamat</th>
                    <td><?php echo e($surat->alamat); ?></td>
                </tr>

                <tr>
                    <th>No Telpon</th>
                    <td><?php echo e($surat->no_telepon); ?></td>
                </tr>

                <tr>
                    <th>Email</th>
                    <td><?php echo e($surat->email); ?></td>
                </tr>

                <tr>
                    <th>Upload KK</th>
                    <td>
                        <a href="<?php echo e(asset('back/img/' . $surat->upload_kk)); ?>" target="_blank">
                            <img src="<?php echo e(asset('back/img/' . $surat->upload_kk)); ?>" width="400px">
                        </a>
                    </td>
                </tr>

                <tr>
                    <th>Berkas Pendukung</th>
                    <td>
                        <?php if($surat->berkas_pendukung): ?>
                            <a href="<?php echo e(asset('back/img/' . $surat->berkas_pendukung)); ?>" target="_blank">
                                <img src="<?php echo e(asset('back/img/' . $surat->berkas_pendukung)); ?>" width="400px">
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>

                <tr>
                    <th>Catatan</th>
                    <td><?php echo e($surat->catatan); ?></td>
                </tr>

                <tr>
                    <th>Tanggal Pengajuan</th>
                    <td><?php echo e(date('d/m/Y', strtotime($surat->created_at))); ?></td>
                </tr>

                <tr>
                    <th>Status</th>
                    <td>
                        <?php if($surat->status == 0): ?>
                            <span class="badge bg-warning">Belum Dikonfirmasi</span>
                        <?php elseif($surat->status == 1): ?>
                            <span class="badge bg-danger">Ditolak</span>
                        <?php elseif($surat->status == 2): ?>
                            <span class="badge bg-primary">Diproses</span>
                        <?php elseif($surat->status == 3): ?>
                            <span class="badge bg-success">Selesai</span>
                        <?php endif; ?>
                    </td>
                </tr>

                <?php if($surat->status == 1): ?>
                    <tr>
                        <th>Alasan Ditolak</th>
                        <td><?php echo e($surat->alasan_ditolak); ?></td>
                    </tr>
                <?php endif; ?>

                <?php if($surat->hasil_surat): ?>
                    <tr>
                        <th>Hasil Surat</th>
                        <td><a href="<?php echo e(asset('back/pdf/'.$surat->hasil_surat)); ?>" target="_blank" rel="noopener noreferrer">Klik untuk melihat</a></td>
                    </tr>
                <?php endif; ?>

            </table>

            <?php if($surat->tipe == 1): ?>
                <div class="float-end">
                    <a href="<?php echo e(url('surat/belum-menikah')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            <?php elseif($surat->tipe == 2): ?>
                <div class="float-end">
                    <a href="<?php echo e(url('surat/ktp-domisili')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            <?php elseif($surat->tipe == 3): ?>
                <div class="float-end">
                    <a href="<?php echo e(url('surat/kematian')); ?>" class="btn btn-secondary">Kembali</a>
                </div>
            <?php endif; ?>
        </div>

        <br><br>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suratdesa\resources\views/back/surat/detail.blade.php ENDPATH**/ ?>