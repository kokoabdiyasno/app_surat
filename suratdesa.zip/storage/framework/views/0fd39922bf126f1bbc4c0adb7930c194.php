<!DOCTYPE html>
<html>

<head>
    <title>Sistem Pengajuan Surat</title>
</head>

<body>
    <p>Hallo admin, ada pengajuan surat masuk melalui sistem dengan detail sebagai berikut :</p>

    <p>Jenis Surat : <?php if($data['tipe'] == 1): ?>
            Belum Menikah
        <?php elseif($data['tipe'] == 2): ?>
            KTP Sementara/Domisili
        <?php else: ?>
            Kematian
        <?php endif; ?>
    </p>
    <p>Nama : <?php echo e($data['nama']); ?></p>
    <p>Jenis Kelamin : <?php echo e($data['jenis_kelamin']); ?></p>
    <p>Tanggal Lahir : <?php echo e(date('d/m/Y', strtotime($data['tanggal_lahir']))); ?></p>
    <p>Email : <?php echo e($data['email']); ?></p>
    <p>No Telepon : <?php echo e($data['no_telepon']); ?></p>
    <p>Alamat/Tempat Tinggal : <?php echo e($data['alamat']); ?></p>
    <p>Catatan : <?php echo e($data['catatan']); ?></p>

    <p>Silahkan login ke sistem untuk melakukan konfirmasi atau Balas pesan ke email : <?php echo e($data['email']); ?></p>
</body>

</html>
<?php /**PATH C:\laragon\www\suratdesa\resources\views/mail/pemberitahuan-pengajuan-email.blade.php ENDPATH**/ ?>